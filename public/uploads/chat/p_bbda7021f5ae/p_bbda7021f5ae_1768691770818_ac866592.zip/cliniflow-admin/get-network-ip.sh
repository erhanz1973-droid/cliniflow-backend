#!/bin/bash
# Cliniflow - Network IP Bulucu
# Bu script Mac'inizin yerel IP adresini bulur (Android emülatör/fiziksel cihaz için)

echo "🌐 Cliniflow Network IP Bulucu"
echo "================================"
echo ""

# Wi-Fi IP adresini bul
WIFI_IP=$(ipconfig getifaddr en0 2>/dev/null)
if [ -n "$WIFI_IP" ]; then
  echo "✅ Wi-Fi IP Adresi (en0):"
  echo "   $WIFI_IP"
  echo ""
  echo "📱 Android cihaz veya emülatör için URL:"
  echo "   http://$WIFI_IP:5050/admin.html"
  echo ""
fi

# Ethernet IP adresini bul
ETH_IP=$(ipconfig getifaddr en1 2>/dev/null)
if [ -n "$ETH_IP" ]; then
  echo "✅ Ethernet IP Adresi (en1):"
  echo "   $ETH_IP"
  echo ""
  echo "📱 Android cihaz veya emülatör için URL:"
  echo "   http://$ETH_IP:5050/admin.html"
  echo ""
fi

# Alternatif yöntem
echo "🔍 Tüm aktif ağ arayüzleri:"
ifconfig | grep -E "^[a-z]|inet " | grep -B1 "inet " | grep -v "127.0.0.1" | grep -v "inet6" || echo "   (Bulunamadı)"

echo ""
echo "📝 Notlar:"
echo "   • Android Studio emülatörü için: http://10.0.2.2:5050/admin.html"
echo "   • Fiziksel cihaz veya diğer emülatörler için yukarıdaki IP'leri kullanın"
echo "   • Mac ve Android cihaz aynı Wi-Fi ağında olmalı"
echo ""
