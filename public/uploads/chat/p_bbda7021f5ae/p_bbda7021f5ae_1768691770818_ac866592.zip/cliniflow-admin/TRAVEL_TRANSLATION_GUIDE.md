# Travel App Ekranı - Türkçe Çeviri Rehberi

## Genel Bakış

Travel API response'unda bazı field name'ler ve değerler İngilizce olarak döndürülüyor. App ekranında bu değerlerin Türkçe karşılıkları gösterilmelidir.

## API Response Yapısı

### GET /api/patient/:patientId/travel

**Response:**
```json
{
  "schemaVersion": 1,
  "updatedAt": 1768054886769,
  "patientId": "p2",
  "hotel": {
    "name": "Test Hotel",
    "address": "Test Address",
    "checkIn": "2026-01-08",
    "checkOut": "2026-01-30",
    "googleMapsUrl": "..."
  },
  "flights": [
    {
      "type": "OUTBOUND",
      "airline": "thy",
      "flightNo": "thy678",
      "from": "lon",
      "to": "ant",
      "date": "2026-01-05",
      "time": "11:00",
      "pnr": "",
      "note": ""
    },
    {
      "type": "RETURN",
      ...
    }
  ],
  "airportPickup": {
    "name": "...",
    "phone": "...",
    "vehicle": "...",
    "plate": "...",
    "meetingPoint": "...",
    "note": "..."
  },
  "notes": "...",
  "editPolicy": {
    "hotel": "ADMIN",
    "flights": "ADMIN",
    "airportPickup": "ADMIN",
    "notes": "ADMIN"
  }
}
```

## Türkçe Çeviri Tablosu

### Flight Type (Uçuş Tipi)

| İngilizce | Türkçe |
|-----------|--------|
| `OUTBOUND` | Gidiş |
| `RETURN` | Dönüş |
| `DEPARTURE` | Dönüş |
| `ARRIVAL` | Geliş |
| `INBOUND` | Geliş |

### Hotel Fields (Otel Alanları)

| İngilizce | Türkçe |
|-----------|--------|
| `checkIn` | Giriş |
| `checkOut` | Çıkış |
| `name` | İsim |
| `address` | Adres |

### Flight Fields (Uçuş Alanları)

| İngilizce | Türkçe |
|-----------|--------|
| `airline` | Havayolu |
| `flightNo` | Uçuş No |
| `pnr` | PNR |
| `from` | Kalkış |
| `to` | Varış |
| `date` | Tarih |
| `time` | Saat |
| `note` | Not |

### Airport Pickup Fields (Havalimanı Karşılama Alanları)

| İngilizce | Türkçe |
|-----------|--------|
| `name` | İsim |
| `phone` | Telefon |
| `vehicle` | Araç |
| `vehicleInfo` | Araç Bilgisi |
| `plate` | Plaka |
| `meetingPoint` | Buluşma Noktası |
| `note` | Not |
| `notes` | Notlar |

## App Ekranında Gösterim Örnekleri

### React Native Örneği

```jsx
// Flight type çevirisi
const getFlightTypeLabel = (type) => {
  const labels = {
    'OUTBOUND': 'Gidiş',
    'RETURN': 'Dönüş',
    'DEPARTURE': 'Dönüş',
    'ARRIVAL': 'Geliş',
    'INBOUND': 'Geliş',
  };
  return labels[type] || type;
};

// Hotel check-in/check-out çevirisi
const getHotelCheckLabel = (type) => {
  const labels = {
    'checkIn': 'Giriş',
    'checkOut': 'Çıkış',
  };
  return labels[type] || type;
};

// Flight detay gösterimi
function renderFlightDetails(flight) {
  return (
    <View>
      <Text>{getFlightTypeLabel(flight.type)} Uçuşu</Text>
      <Text>Havayolu: {flight.airline}</Text>
      <Text>Uçuş No: {flight.flightNo}</Text>
      {flight.pnr && <Text>PNR: {flight.pnr}</Text>}
      <Text>Kalkış: {flight.from?.toUpperCase()}</Text>
      <Text>Varış: {flight.to?.toUpperCase()}</Text>
      <Text>Tarih: {flight.date}</Text>
      {flight.time && <Text>Saat: {flight.time}</Text>}
      {flight.note && <Text>Not: {flight.note}</Text>}
    </View>
  );
}

// Hotel detay gösterimi
function renderHotelDetails(hotel) {
  return (
    <View>
      <Text>Otel: {hotel.name}</Text>
      {hotel.address && <Text>Adres: {hotel.address}</Text>}
      {hotel.checkIn && <Text>Giriş: {hotel.checkIn}</Text>}
      {hotel.checkOut && <Text>Çıkış: {hotel.checkOut}</Text>}
    </View>
  );
}

// Airport pickup detay gösterimi
function renderAirportPickup(pickup) {
  return (
    <View>
      <Text>🚗 Havalimanı Karşılama</Text>
      {pickup.name && <Text>İsim: {pickup.name}</Text>}
      {pickup.phone && <Text>Telefon: {pickup.phone}</Text>}
      {(pickup.vehicle || pickup.vehicleInfo) && (
        <Text>
          Araç: {pickup.vehicle || pickup.vehicleInfo}
          {pickup.plate && `, Plaka: ${pickup.plate}`}
        </Text>
      )}
      {pickup.meetingPoint && <Text>Buluşma: {pickup.meetingPoint}</Text>}
      {(pickup.note || pickup.notes) && (
        <Text>Not: {pickup.note || pickup.notes}</Text>
      )}
    </View>
  );
}
```

### Flutter Örneği

```dart
// Flight type çevirisi
String getFlightTypeLabel(String? type) {
  const labels = {
    'OUTBOUND': 'Gidiş',
    'RETURN': 'Dönüş',
    'DEPARTURE': 'Dönüş',
    'ARRIVAL': 'Geliş',
    'INBOUND': 'Geliş',
  };
  return labels[type] ?? type ?? '';
}

// Hotel check-in/check-out çevirisi
String getHotelCheckLabel(String type) {
  const labels = {
    'checkIn': 'Giriş',
    'checkOut': 'Çıkış',
  };
  return labels[type] ?? type;
}

// Flight detay widget
Widget buildFlightDetails(Map<String, dynamic> flight) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('${getFlightTypeLabel(flight['type'])} Uçuşu'),
      if (flight['airline'] != null) Text('Havayolu: ${flight['airline']}'),
      if (flight['flightNo'] != null) Text('Uçuş No: ${flight['flightNo']}'),
      if (flight['pnr'] != null && flight['pnr'].toString().isNotEmpty)
        Text('PNR: ${flight['pnr']}'),
      Text('Kalkış: ${(flight['from'] ?? '').toString().toUpperCase()}'),
      Text('Varış: ${(flight['to'] ?? '').toString().toUpperCase()}'),
      Text('Tarih: ${flight['date'] ?? ''}'),
      if (flight['time'] != null && flight['time'].toString().isNotEmpty)
        Text('Saat: ${flight['time']}'),
      if (flight['note'] != null && flight['note'].toString().isNotEmpty)
        Text('Not: ${flight['note']}'),
    ],
  );
}

// Hotel detay widget
Widget buildHotelDetails(Map<String, dynamic>? hotel) {
  if (hotel == null) return SizedBox.shrink();
  
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('Otel: ${hotel['name'] ?? ''}'),
      if (hotel['address'] != null && hotel['address'].toString().isNotEmpty)
        Text('Adres: ${hotel['address']}'),
      if (hotel['checkIn'] != null) Text('Giriş: ${hotel['checkIn']}'),
      if (hotel['checkOut'] != null) Text('Çıkış: ${hotel['checkOut']}'),
    ],
  );
}

// Airport pickup detay widget
Widget buildAirportPickup(Map<String, dynamic>? pickup) {
  if (pickup == null) return SizedBox.shrink();
  
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('🚗 Havalimanı Karşılama'),
      if (pickup['name'] != null) Text('İsim: ${pickup['name']}'),
      if (pickup['phone'] != null) Text('Telefon: ${pickup['phone']}'),
      if ((pickup['vehicle'] ?? pickup['vehicleInfo']) != null) ...[
        Text(
          'Araç: ${pickup['vehicle'] ?? pickup['vehicleInfo']}'
          '${pickup['plate'] != null ? ", Plaka: ${pickup['plate']}" : ""}'
        ),
      ],
      if (pickup['meetingPoint'] != null) 
        Text('Buluşma: ${pickup['meetingPoint']}'),
      if ((pickup['note'] ?? pickup['notes']) != null)
        Text('Not: ${pickup['note'] ?? pickup['notes']}'),
    ],
  );
}
```

## Önemli Notlar

1. **Field Name'ler**: API response'undaki field name'ler (örn: `checkIn`, `flightNo`) İngilizce olarak kalmalıdır. Sadece app ekranında gösterilen label'lar ve değerler Türkçeleştirilmelidir.

2. **Flight Type**: `OUTBOUND` ve `RETURN` değerleri için Türkçe karşılıklar mutlaka kullanılmalıdır.

3. **Hotel Check-in/Check-out**: `checkIn` ve `checkOut` field name'leri İngilizce kalır, ama ekranda "Giriş" ve "Çıkış" olarak gösterilmelidir.

4. **Büyük/Küçük Harf**: Flight type değerleri (`OUTBOUND`, `RETURN`, vb.) genellikle büyük harfle gelir, ama app'da gösterirken Türkçe karşılığı kullanılmalıdır.

5. **Boş Değerler**: Boş string veya null olan değerler gösterilmemelidir.

6. **IATA Kodları**: `from` ve `to` field'ları IATA havaalanı kodları içerir (örn: "IST", "TBS"). Bunlar büyük harfle gösterilebilir ama çevrilmezler.

## Örnek Tam Ekran Gösterimi

```
✈️ Uçuş Bilgileri
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Gidiş Uçuşu
  Kalkış: LON → Varış: ANT
  Havayolu: Turkish Airlines
  Uçuş No: TK 567
  Tarih: 2026-01-08
  Saat: 14:30
  PNR: ABC123
  Not: Ek bagaj: 23kg

Dönüş Uçuşu
  Kalkış: ANT → Varış: LON
  Havayolu: Turkish Airlines
  Uçuş No: TK 843
  Tarih: 2026-01-26
  Saat: 18:00

🏨 Otel Bilgileri
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Otel: Radisson Hotel
Adres: Güzeloba, Havaalanı Cd. No:104 A
Giriş: 2026-01-08
Çıkış: 2026-01-30

🚗 Havalimanı Karşılama
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
İsim: Ali Naci
Telefon: +905437676764
Araç: White Toyota Prius, Plaka: 07 KL 937
Buluşma: Gate B
Not: Our staff will be waiting for you with a sign displaying your name.
```
