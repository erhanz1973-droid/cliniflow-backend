# App Home Ekranı - Klinik Branding Bilgileri

## Genel Bakış

Pro pakette, hasta uygulamasının home ekranının tepesinde detaylı klinik bilgileri gösterilmelidir. Bu bilgiler `/api/patient/me` endpoint'inden alınır ve yalnızca `clinicPlan === "PRO"` olduğunda `branding` objesi döndürülür.

## API Endpoint

### GET /api/patient/me

**Headers:**
```
Authorization: Bearer <patient_token>
```

**Response (PRO plan için):**
```json
{
  "ok": true,
  "patientId": "p_123",
  "clinicPlan": "PRO",
  "branding": {
    "clinicName": "Moon Smile Clinic",
    "clinicLogoUrl": "https://moonsmileclinic.com/assets/img/logos/logo-dark.png",
    "address": "Güzeloba, Havaalanı Cd. No:104 A, 07230 Muratpaşa/Antalya",
    "googleMapLink": "https://maps.app.goo.gl/kRmy4ZNCMkuMscxJ6",
    "primaryColor": "#2563EB",
    "secondaryColor": "#10B981",
    "welcomeMessage": "Hoş geldiniz...",
    "showPoweredBy": true,
    "phone": "+995514661161"
  }
}
```

**Response (FREE/BASIC plan için):**
```json
{
  "ok": true,
  "patientId": "p_123",
  "clinicPlan": "FREE",
  "branding": null
}
```

## App Home Ekranı Görünümü

### Pro Paket İçin

Home ekranının tepesinde şu bilgiler gösterilmelidir:

1. **Klinik Logosu** (`branding.clinicLogoUrl`)
   - Logo varsa gösterilmeli
   - Logo yoksa gösterilmemeli (boş bırakılabilir)

2. **Klinik İsmi** (`branding.clinicName`)
   - Büyük ve belirgin şekilde gösterilmeli

3. **Klinik Adresi** (`branding.address`)
   - Klinik isminin altında gösterilmeli

4. **Google Maps Linki** (`branding.googleMapLink`)
   - Adresin yanında veya altında bir buton/ikon olarak gösterilmeli
   - Tıklandığında Google Maps'te açılmalı
   - Link varsa gösterilmeli, yoksa gösterilmemeli

### Örnek Layout

```
┌─────────────────────────────────┐
│  [Klinik Logosu]                 │
│                                  │
│  Moon Smile Clinic               │
│  Güzeloba, Havaalanı Cd...      │
│  [📍 Haritada Aç]                │
└─────────────────────────────────┘
```

### Örnek React Native Kodu

```jsx
import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, Linking } from 'react-native';

function HomeScreen() {
  const [branding, setBranding] = useState(null);
  const [clinicPlan, setClinicPlan] = useState('FREE');

  useEffect(() => {
    loadBranding();
  }, []);

  async function loadBranding() {
    try {
      const token = await getPatientToken(); // Token'ı storage'dan al
      const response = await fetch(`${API_BASE}/api/patient/me`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json'
        }
      });
      const data = await response.json();
      
      if (data.ok && data.clinicPlan === 'PRO' && data.branding) {
        setBranding(data.branding);
        setClinicPlan(data.clinicPlan);
      }
    } catch (error) {
      console.error('Load branding error:', error);
    }
  }

  async function openGoogleMaps() {
    if (branding?.googleMapLink) {
      const canOpen = await Linking.canOpenURL(branding.googleMapLink);
      if (canOpen) {
        await Linking.openURL(branding.googleMapLink);
      }
    }
  }

  if (clinicPlan !== 'PRO' || !branding) {
    // FREE/BASIC plan için normal home ekranı
    return <NormalHomeScreen />;
  }

  return (
    <View style={styles.container}>
      {/* Klinik Bilgileri Header */}
      <View style={styles.clinicHeader}>
        {branding.clinicLogoUrl && (
          <Image 
            source={{ uri: branding.clinicLogoUrl }} 
            style={styles.logo}
            resizeMode="contain"
          />
        )}
        <Text style={styles.clinicName}>{branding.clinicName}</Text>
        {branding.address && (
          <Text style={styles.address}>{branding.address}</Text>
        )}
        {branding.googleMapLink && (
          <TouchableOpacity 
            style={styles.mapButton}
            onPress={openGoogleMaps}
          >
            <Text style={styles.mapButtonText}>📍 Haritada Aç</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Diğer home ekranı içeriği */}
      {/* ... */}
    </View>
  );
}

const styles = {
  clinicHeader: {
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    alignItems: 'center',
  },
  logo: {
    width: 120,
    height: 60,
    marginBottom: 12,
  },
  clinicName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  address: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 12,
  },
  mapButton: {
    padding: 8,
    backgroundColor: '#2563EB',
    borderRadius: 8,
  },
  mapButtonText: {
    color: '#fff',
    fontSize: 14,
  },
};
```

### Örnek Flutter Kodu

```dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic>? branding;
  String clinicPlan = 'FREE';

  @override
  void initState() {
    super.initState();
    loadBranding();
  }

  Future<void> loadBranding() async {
    try {
      final token = await getPatientToken(); // Token'ı storage'dan al
      final response = await http.get(
        Uri.parse('$API_BASE/api/patient/me'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/json',
        },
      );
      
      final data = jsonDecode(response.body);
      if (data['ok'] == true && 
          data['clinicPlan'] == 'PRO' && 
          data['branding'] != null) {
        setState(() {
          branding = data['branding'];
          clinicPlan = data['clinicPlan'];
        });
      }
    } catch (e) {
      print('Load branding error: $e');
    }
  }

  Future<void> openGoogleMaps() async {
    final link = branding?['googleMapLink'];
    if (link != null && link.isNotEmpty) {
      final uri = Uri.parse(link);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (clinicPlan != 'PRO' || branding == null) {
      return NormalHomeScreen();
    }

    return Scaffold(
      body: Column(
        children: [
          // Klinik Bilgileri Header
          Container(
            padding: EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              children: [
                if (branding!['clinicLogoUrl'] != null && 
                    branding!['clinicLogoUrl'].toString().isNotEmpty)
                  Image.network(
                    branding!['clinicLogoUrl'],
                    width: 120,
                    height: 60,
                    fit: BoxFit.contain,
                  ),
                SizedBox(height: 12),
                Text(
                  branding!['clinicName'] ?? '',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                if (branding!['address'] != null && 
                    branding!['address'].toString().isNotEmpty) ...[
                  SizedBox(height: 8),
                  Text(
                    branding!['address'],
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
                if (branding!['googleMapLink'] != null && 
                    branding!['googleMapLink'].toString().isNotEmpty) ...[
                  SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: openGoogleMaps,
                    icon: Icon(Icons.map),
                    label: Text('Haritada Aç'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF2563EB),
                    ),
                  ),
                ],
              ],
            ),
          ),
          // Diğer home ekranı içeriği
          Expanded(
            child: NormalHomeContent(),
          ),
        ],
      ),
    );
  }
}
```

## Notlar

1. **Pro Paket Kontrolü**: Branding bilgileri yalnızca `clinicPlan === "PRO"` olduğunda gösterilmelidir.

2. **Opsiyonel Alanlar**: 
   - Logo yoksa gösterilmemeli
   - Adres yoksa gösterilmemeli
   - Google Maps linki yoksa buton gösterilmemeli

3. **Renkler**: `primaryColor` ve `secondaryColor` branding objesinde mevcuttur ancak home header için zorunlu değildir. İsteğe bağlı olarak kullanılabilir.

4. **Logo Yükleme**: Logo URL'i geçerli bir HTTP/HTTPS URL olmalıdır. Hata durumunda fallback gösterilmeli veya logo alanı gizlenmelidir.

5. **Google Maps Link**: Link tıklandığında cihazın varsayılan tarayıcısında veya Google Maps uygulamasında açılmalıdır.
